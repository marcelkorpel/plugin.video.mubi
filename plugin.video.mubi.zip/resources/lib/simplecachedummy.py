'''
     SimpleCache dummy
     Version: 1.0
'''


class SimpleCache:
    def __init__(self):
        return None

    def set(self, name, data, expiration=None):
        return None

    def get(self, name):
        return None

